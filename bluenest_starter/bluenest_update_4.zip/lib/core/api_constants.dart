class ApiConstants {
  /// Teammate's backend on Render. Override at build time if needed:
  ///   flutter run --dart-define=BASE_URL=http://10.0.2.2:8000
  static const String baseUrl = String.fromEnvironment(
    'BASE_URL',
    defaultValue: 'https://teamblue.onrender.com',
  );

  // Accounts
  static const String login = '/api/accounts/login/';
  static const String register = '/api/accounts/register/';

  // Listings  (all from the shared Postman collection)
  static const String properties = '/api/listing/properties/'; // GET list
  static const String createProperty = '/api/listing/properties/create/'; // POST
  static String property(int id) => '/api/listing/properties/$id/'; // GET
  static String updateProperty(int id) => '/api/listing/properties/$id/update/'; // PUT
  static String partialUpdateProperty(int id) =>
      '/api/listing/properties/$id/partial-update/'; // PATCH
  static String deleteProperty(int id) => '/api/listing/properties/$id/delete/'; // DELETE
}
