/// Developer switches. Remove / set to false before release.
class DevConfig {
  /// When true, "Log in" skips validation + the API and opens the dashboard.
  /// NOTE: with the real backend connected this must stay FALSE if you want
  /// to call protected APIs (properties etc.) - the bypass has no access token,
  /// so those calls come back 401.
  static const bool bypassLogin = false;
}
