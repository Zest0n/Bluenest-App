import 'package:flutter/material.dart';

/// BlueNest palette - built around the logo blue (#1800AD).
class AppColors {
  // Brand (from the logo)
  static const Color primary = Color(0xFF1800AD); // Logo blue - CTAs, links, icons
  static const Color midnight = Color(0xFF0B0050); // Darkest brand shade - dark surfaces
  static const Color sidebarActive = Color(0xFF130088); // Selected item on dark surfaces
  static const Color secondary = Color(0xFF5D4DC6); // Lighter brand blue - secondary actions
  static const Color primarySoft = Color(0xFFECEBF8); // Very light tint - icon circles, chips
  static const Color accent = Color(0xFFFF7D61); // Coral - small highlights only

  // Neutrals & surfaces
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color border = Color(0xFFE2E8F0);
  static const Color background = Color(0xFFF5F5FB); // Canvas (faint blue tint)
  static const Color surface = Color(0xFFFFFFFF); // Cards

  // Functional / status (background + foreground pairs)
  static const Color successBg = Color(0xFFDCFCE7);
  static const Color success = Color(0xFF15803D);
  static const Color warningBg = Color(0xFFFFEDD5);
  static const Color warning = Color(0xFFC2410C);
  static const Color dangerBg = Color(0xFFFEE2E2);
  static const Color danger = Color(0xFFB91C1C);
  static const Color infoBg = Color(0xFFDBEAFE);
  static const Color info = Color(0xFF1D4ED8);
}
