import 'package:flutter/material.dart';
import '../../core/app_colors.dart';
import '../../models/property.dart';
import '../../services/property_service.dart';

/// Screen 8 (landlord): Add / Edit Property.
/// property == null -> Add (POST create), otherwise Edit (PATCH partial-update).
/// Pops with `true` when saved so My Properties refreshes.
class AddEditPropertyScreen extends StatefulWidget {
  final Property? property;
  const AddEditPropertyScreen({super.key, this.property});

  @override
  State<AddEditPropertyScreen> createState() => _AddEditPropertyScreenState();
}

class _AddEditPropertyScreenState extends State<AddEditPropertyScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _description;
  late final TextEditingController _city;
  late final TextEditingController _locality;
  late final TextEditingController _size;
  int _bhk = 2;
  bool _saving = false;

  bool get _isEdit => widget.property != null;

  @override
  void initState() {
    super.initState();
    final p = widget.property;
    _title = TextEditingController(text: p?.title ?? '');
    _description = TextEditingController(text: p?.description ?? '');
    _city = TextEditingController(text: p?.city ?? '');
    _locality = TextEditingController(text: p?.locality ?? '');
    _size = TextEditingController(
        text: p?.sizeSqft != null ? p!.sizeSqft!.round().toString() : '');
    if (p?.bhk != null && p!.bhk! >= 1 && p.bhk! <= 6) _bhk = p.bhk!;
  }

  @override
  void dispose() {
    for (final c in [_title, _description, _city, _locality, _size]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    // TODO: add the remaining fields (rent, deposit, furnishing, ...) once the
    // backend create schema is confirmed.
    final body = <String, dynamic>{
      'title': _title.text.trim(),
      'description': _description.text.trim(),
      'city': _city.text.trim(),
      'locality': _locality.text.trim(),
      'bhk': _bhk,
      'size_sqft': num.parse(_size.text.trim()),
    };

    final res = _isEdit
        ? await PropertyService.partialUpdate(widget.property!.id, body)
        : await PropertyService.create(body);

    if (!mounted) return;
    setState(() => _saving = false);

    if (res.ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(_isEdit ? 'Property updated' : 'Property listed')));
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(res.error ?? 'Could not save'),
          backgroundColor: AppColors.danger));
    }
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Required' : null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit Property' : 'Add Property')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _title,
                    decoration: const InputDecoration(
                        labelText: 'Title', hintText: 'e.g. 2 BHK Flat in Noida'),
                    validator: _required,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _description,
                    maxLines: 4,
                    decoration: const InputDecoration(
                        labelText: 'Description', alignLabelWithHint: true),
                    validator: _required,
                  ),
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(
                      child: TextFormField(
                          controller: _city,
                          decoration: const InputDecoration(labelText: 'City'),
                          validator: _required),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                          controller: _locality,
                          decoration: const InputDecoration(labelText: 'Locality'),
                          validator: _required),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(
                      child: DropdownButtonFormField<int>(
                        value: _bhk,
                        decoration: const InputDecoration(labelText: 'BHK'),
                        items: [
                          for (var i = 1; i <= 6; i++)
                            DropdownMenuItem(value: i, child: Text('$i BHK')),
                        ],
                        onChanged: (v) => setState(() => _bhk = v ?? _bhk),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _size,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(labelText: 'Size (sq ft)'),
                        validator: (v) =>
                            (num.tryParse(v?.trim() ?? '') == null) ? 'Enter a number' : null,
                      ),
                    ),
                  ]),
                  const SizedBox(height: 28),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                            minimumSize: const Size.fromHeight(52),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14))),
                        onPressed: _saving ? null : () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _saving ? null : _save,
                        child: _saving
                            ? const SizedBox(
                                height: 22,
                                width: 22,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white))
                            : Text(_isEdit ? 'Save changes' : 'Save Property'),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
